package com.tour.app;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.tour.app.containers.Destination;
import com.tour.app.containers.Operator;
import com.tour.app.containers.Tour;

import java.util.ArrayList;
import java.util.List;

import io.apptik.widget.MultiSlider;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    List<Destination> destTest = new ArrayList<Destination>();
    List<Destination> user_sel_destTest = new ArrayList<Destination>();
    List<Operator> operators = new ArrayList<Operator>();
    List<Operator> sel_operators = new ArrayList<Operator>();


    TextView txt_sel_operator, txt_sel_country;
    TextView txt_search;

    MultiSlider range_slider;
    TextView txt_selectedrange;

    int minPrice = 1;
    int maxPrice = 3000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        setPriceSelector();
        addCountry();
        addOperator();


    }


    public void initViews() {
        txt_selectedrange = findViewById(R.id.txt_selectedrange);
        range_slider = findViewById(R.id.range_slider);
        txt_sel_operator = findViewById(R.id.txt_sel_operator);
        txt_sel_operator.setOnClickListener(this);
        txt_sel_country = findViewById(R.id.txt_sel_country);
        txt_sel_country.setOnClickListener(this);
        txt_search = findViewById(R.id.txt_search);


        txt_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputes())
                    getResults();
            }
        });

    }

    public boolean validateInputes() {

        if (sel_operators.size() == 0) {
            Toast.makeText(MainActivity.this, "Please select operator.", Toast.LENGTH_SHORT).show();
            return false;
        } else if (user_sel_destTest.size() == 0) {
            Toast.makeText(MainActivity.this, "Please select country.", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    ProgressDialog progressDialog = null;
    int progress = 0;
    int progress_temp=0;
    public void getResults() {
        new AsyncTask<Void, Void,  Void>() {
            ArrayList<Tour> output = new ArrayList<>();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(MainActivity.this);
                progressDialog.setTitle("Searching tours");
                progressDialog.setMessage("Please wailt...");
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.show();
               // progress = (100 / (sel_operators.size()));

            }

            @Override
            protected  Void doInBackground(Void... voids) {

                for (int i = 0; i < sel_operators.size(); i++) {
                 //  if(i==(sel_operators.size()-1)) progress_temp=100;
                   output.addAll(sel_operators.get(i).getOperatorObject().parseWithParameters(user_sel_destTest, minPrice, maxPrice));
                 //   progress_temp=(progress*(i+1));
                   /* runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressDialog.setMessage("Please wailt..."+progress_temp+"%");
                        }
                    });*/
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                progressDialog.dismiss();
                if (output.size() > 0) {
                    Intent intent = new Intent(MainActivity.this, PackageActivity.class);
                    intent.putExtra("package_list", output);
                    startActivity(intent);
                }

                else{
                    Toast.makeText(MainActivity.this, "Tour not found.", Toast.LENGTH_SHORT).show();
                }


           /*     new Thread(){
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(1000);
                            progress_temp=0;
                            progress=0;
                            sel_operators.clear();
                            user_sel_destTest.clear();
                            progressDialog.dismiss();
                            Log.i("results24234", "" + output.size());

                            if (output.size() > 0) {
                                Intent intent = new Intent(MainActivity.this, PackageActivity.class);
                                intent.putExtra("package_list", output);
                                startActivity(intent);
                            }

                            else{
                                Toast.makeText(MainActivity.this, "Tour not found.", Toast.LENGTH_SHORT).show();
                            }

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();*/



                /*for (int i = 0; i < output.size(); i++){
                    System.out.println(
                            "\nPrice - " + output.get(i).getPrice() +
                                    "\nDestination - " + output.get(i).getDestination() +
                                    "\nDaysPeriod - " + output.get(i).getPeriodInDays() +
                                    "\nSummary - " + output.get(i).getSummary() +
                                    "\nLink - " + output.get(i).getDirectLink()
                    );
                }*/


            }
        }.execute();
    }

    public void addOperator() {
        operators.add(Operator.EXPLORE);
        operators.add(Operator.ALPIMARIN);
        operators.add(Operator.CITYBREAK);
        operators.add(Operator.COCOSTUR);
        operators.add(Operator.METEORTRAVEL);
    }

    public void addCountry() {
        destTest.add(Destination.USA);
        destTest.add(Destination.CZECH);
        destTest.add(Destination.BULGARIA);
        destTest.add(Destination.ROMANIA);
        destTest.add(Destination.MOLDOVA);
        destTest.add(Destination.GERMANY);
        destTest.add(Destination.BELGIUM);
        destTest.add(Destination.FRANCE);
        destTest.add(Destination.GREECE);
        destTest.add(Destination.UKRAINE);
        destTest.add(Destination.TURKEY);
        destTest.add(Destination.AUSTRIA);
        destTest.add(Destination.EGYPT);
        destTest.add(Destination.ITALY);
        destTest.add(Destination.SPAIN);
        destTest.add(Destination.RUSSIA);
        destTest.add(Destination.MONTENEGRO);
    }


    private void countryPopup(final TextView anchor) {
        LayoutInflater mInflater = LayoutInflater.from(this);
        final ViewGroup rootView = (ViewGroup) mInflater.inflate(R.layout.tourdialog_view, null);
        rootView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        PopupWindow popup = new PopupWindow(this);
        popup.setBackgroundDrawable(getResources().getDrawable(R.color.transparent));
        popup.setContentView(rootView);
        popup.setTouchable(true);
        popup.setOutsideTouchable(true);
        //If focusable is false, in a Activity pops up a PopupWindow, press the return key, because PopupWindow is not the focus, will directly from the Activity. If focusable is true, PopupWindow pop-up, touch screen and physical keys all have PopupWindows processing.
        popup.setFocusable(false);

        user_sel_destTest.clear();
        LinearLayout tour_layout = rootView.findViewById(R.id.tour_layout);
        ImageView ic_cancel = rootView.findViewById(R.id.ic_cancel);

        ic_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popup.dismiss();
            }
        });


        for (int i = 0; i < destTest.size(); i++) {
            View view = mInflater.inflate(R.layout.touroperatorview, null);
            TextView textView = view.findViewById(R.id.name);
            ImageView imageView = view.findViewById(R.id.right_tick);
            textView.setTag(i);
            textView.setText("" + destTest.get(i));

            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (imageView.getVisibility() == View.VISIBLE) {
                        imageView.setVisibility(View.GONE);
                        user_sel_destTest.remove(destTest.get((int) v.getTag()));
                    } else {
                        imageView.setVisibility(View.VISIBLE);
                        user_sel_destTest.add(destTest.get((int) v.getTag()));
                    }


                }
            });

            tour_layout.addView(view);
        }


        popup.showAsDropDown(anchor);


    }

    private void operatorPopup(final TextView anchor) {
        LayoutInflater mInflater = LayoutInflater.from(this);
        final ViewGroup rootView = (ViewGroup) mInflater.inflate(R.layout.tourdialog_view, null);
        rootView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        PopupWindow popup = new PopupWindow(this);
        popup.setBackgroundDrawable(getResources().getDrawable(R.color.transparent));
        popup.setContentView(rootView);
        popup.setTouchable(true);
        popup.setOutsideTouchable(true);
        //If focusable is false, in a Activity pops up a PopupWindow, press the return key, because PopupWindow is not the focus, will directly from the Activity. If focusable is true, PopupWindow pop-up, touch screen and physical keys all have PopupWindows processing.
        popup.setFocusable(false);

        sel_operators.clear();
        LinearLayout tour_layout = rootView.findViewById(R.id.tour_layout);
        ImageView ic_cancel = rootView.findViewById(R.id.ic_cancel);

        ic_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popup.dismiss();
            }
        });

        for (int i = 0; i < operators.size(); i++) {
            View view = mInflater.inflate(R.layout.touroperatorview, null);
            TextView textView = view.findViewById(R.id.name);
            ImageView imageView = view.findViewById(R.id.right_tick);
            textView.setTag(i);
            textView.setText("" + operators.get(i));

            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (imageView.getVisibility() == View.VISIBLE) {
                        imageView.setVisibility(View.GONE);
                        sel_operators.remove(operators.get((int) v.getTag()));
                    } else {
                        imageView.setVisibility(View.VISIBLE);
                        sel_operators.add(operators.get((int) v.getTag()));
                    }


                }
            });

            tour_layout.addView(view);
        }


        popup.showAsDropDown(anchor);


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.txt_sel_operator:
                operatorPopup(txt_sel_operator);
                break;

            case R.id.txt_sel_country:
                countryPopup(txt_sel_country);
                break;


        }
    }


    private void setPriceSelector() {

        range_slider.setOnThumbValueChangeListener(new MultiSlider.OnThumbValueChangeListener() {
            @Override
            public void onValueChanged(MultiSlider multiSlider, MultiSlider.Thumb thumb, int thumbIndex, int value) {

                if (thumbIndex == 0)
                    minPrice = value;
                else if (thumbIndex == 1)
                    maxPrice = value;

                txt_selectedrange.setText("" + minPrice + " - " + maxPrice + "\u20ac");
            }
        });
    }
}
