package com.tour.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.tour.app.containers.Tour;

import java.util.ArrayList;
import java.util.List;

public class PackageActivity extends AppCompatActivity {

    Context mContext;
    RecyclerView list_package;
    List<Tour> packagelist=new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.packageactivity);
        mContext=this;

        Intent intent=getIntent();

        if(intent!=null){
            packagelist= (ArrayList<Tour>) intent.getSerializableExtra("package_list");
        }

        else{
            return;
        }


        initViews();
    }


    public void initViews(){
        list_package=findViewById(R.id.list_package);
        PAckageAdapter pAckageAdapter=new PAckageAdapter(mContext,packagelist);
        RecyclerView.LayoutManager  layoutManager=new LinearLayoutManager(mContext);
        list_package.setLayoutManager(layoutManager);
        list_package.setAdapter(pAckageAdapter);
    }
}
