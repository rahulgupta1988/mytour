package com.tour.app;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.tour.app.containers.Tour;

import java.util.List;

public class PAckageAdapter extends RecyclerView.Adapter<PAckageAdapter.ViewHolder> {

    Context mContext;
    List<Tour> package_list;


    public PAckageAdapter(Context mContext, List<Tour> package_list){
        this.mContext=mContext;
        this.package_list=package_list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.packageslistview,null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Tour tour=package_list.get(i);

        if(tour.getDestination()!=null){
            viewHolder.txt_countryname.setText(""+tour.getDestination());
        }

        if(tour.getSummary()!=null){
            viewHolder.txt_summery.setText("Summary:\n"+tour.getSummary());
        }


        viewHolder.txt_price.setText("Price: "+tour.getPrice()+"€");

        if(tour.getPeriodInDays()!=null && tour.getPeriodInDays()!=-1){
            viewHolder.txt_days.setText("Days: "+tour.getPeriodInDays());
        }

        else{
            viewHolder.txt_days.setText("Days: unknown");
        }


        if(tour.getDirectLink()!=null){
            viewHolder.txt_link.setText("soruce link:\n"+tour.getDirectLink());
        }


    }

    @Override
    public int getItemCount() {
        return package_list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        TextView txt_countryname,txt_summery,txt_price,txt_days,txt_link;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_countryname=itemView.findViewById(R.id.txt_countryname);
            txt_summery=itemView.findViewById(R.id.txt_summery);
            txt_price=itemView.findViewById(R.id.txt_price);
            txt_days=itemView.findViewById(R.id.txt_days);
            txt_link=itemView.findViewById(R.id.txt_link);
        }
    }



}
